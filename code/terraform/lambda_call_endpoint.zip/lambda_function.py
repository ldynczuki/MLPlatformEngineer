import os
import io
import boto3
import json
import csv


runtime = boto3.client('runtime.sagemaker')
client_sagemaker = boto3.client('sagemaker')
endpoint_name = 'linear-learner'


def lambda_handler(event, context):

    endpoint_list = client_sagemaker.list_endpoints()
    
    for i in range(len(endpoint_list['Endpoints'])):
        if endpoint_name in endpoint_list['Endpoints'][i]['EndpointName']:
            endpoint = endpoint_list['Endpoints'][i]['EndpointName']
        else:
            endpoint = 'não existe endpoint'
    
    print("Received event: " + json.dumps(event, indent=2))
    
    data = json.loads(json.dumps(event))
    payload = data['data']
    print(payload)

    response = runtime.invoke_endpoint(EndpointName=endpoint,
                                       ContentType='text/csv',
                                       Body=payload)

    result = json.loads(response['Body'].read().decode())

    
    return {'predict': result}

