from __future__ import print_function
from io import StringIO
import boto3
import base64
import json
import csv
from datetime import datetime


def lambda_handler(event, context):
    
    """
    Recebe o dado do Kinesis Data Firehose. 
    Aplica uma transformação dos dados, capturando apenas as chaves
    necessárias para o treinamento do modelo.
    Posteriormente, salva os dados em um arquivo csv num arquivo temporário,
    Por fim, faz o upload deste arquivo csv já tratado para o bucket, 
    no diretório 'processing-sucess' e contendo a data e hora 
    da transformação do dado.
    
    output_data:
        - bucket/processing-sucess/%Y%m%d%H%M"_clean.csv
    """
    
    now = datetime.now()
    dt_string = now.strftime("%Y%m%d%H%M")
    keyName = 'processing-sucess/' + dt_string + '_' + 'clean.csv'
    bucketName = 'cleaned-bucket-platform'
    
    list_keys = ['id', 'name', 'abv', 
            'ibu', 'target_fg', 
            'target_og', 'ebc', 'srm', 'ph']
        
    for record in event['records']:
        payload = base64.b64decode(record['data'])
        payload_decode = payload.decode("UTF-8")
        list_payload = json.loads(payload_decode)
        
        result = {}
        for key in list_keys:
            result[key] = list_payload[0][key]
    
    with open('/tmp/clean.csv', 'w+') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=list_keys)
        writer.writerow(result)
        

    client_s3 = boto3.client("s3")
    client_s3.upload_file(Filename='/tmp/clean.csv', 
                          Bucket=bucketName, 
                          Key=keyName)
 
    print('Successfully processed {} records.'.format(len(event['records'])))

    return {'status': 200}
