from botocore.vendored import requests
import json
import boto3


def lambda_handler(event, context):
    
    """
    Realiza o consumo da Punk API no endpoint e 
    ingere o dado em um Kinesis Stream
    """
    
    payload = requests.get('https://api.punkapi.com/v2/beers/random').json()
    payload_json = json.dumps(payload)
    payload_bytes = bytes(payload_json, 'utf-8')

    kinesis_client = boto3.client('kinesis')
    response = kinesis_client.put_record(StreamName='kinesis_stream',
                                         Data=payload_bytes,
                                         PartitionKey=str(payload[0]['id']))
    

    return {'statusCode': 200,
            'body': response}

